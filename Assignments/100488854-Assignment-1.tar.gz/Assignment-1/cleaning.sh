find . -name "NOTES" -exec rm -rf {} \;
mkdir cleaned_data
mv -v ~/Desktop/Assignments/Assignment-1/data/* ~/Desktop/Assignments/Assignment-1/cleaned_data/
